$(document).ready(function()
{
    $("body").keydown("#ticketrestaurantmobile_mobilephone",function (e) {
    // Allow: backspace, delete, tab, escape, enter and .
    if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110]) !== -1 ||
        // Allow: Ctrl+A, Command+A
        (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
        // Allow: home, end, left, right, down, up
        (e.keyCode >= 35 && e.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
    }
    // Ensure that it is a number and stop the keypress
    if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
        e.preventDefault();
    }

    if ($(this).val().length > 8) {
      e.preventDefault();
    }
  });

  function checkIfFilled(event)
  {
      if ($("#ticketrestaurantmobile_mobilephone").val().trim() === ''
          || $("#ticketrestaurantmobile_mobilephone").val().length !== 9) {

          $('#ticketrestaurantmobile_mobilephone_error').fadeIn();
          setTimeout(function () {
              $('#ticketrestaurantmobile_mobilephone_error').fadeOut();
          }, 5000);

          event.preventDefault();

      return false;
    }
  }

    $('#payment-confirmation').click(function (event) {
        var urlParams = new URLSearchParams(window.location.search);

        if (urlParams.has('module')
            && urlParams.get('module') === 'ticketrestaurantmobile') {
            return checkIfFilled(event);
        } 

        return true;
    });

});