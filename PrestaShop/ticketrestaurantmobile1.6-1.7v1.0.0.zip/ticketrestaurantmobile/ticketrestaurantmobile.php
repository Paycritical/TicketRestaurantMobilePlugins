<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class TicketRestaurantMobile extends PaymentModule
{
  const FLAG_DISPLAY_PAYMENT_INVITE = 'TICKETRESTAURANTMOBILE_PAYMENT_INVITE';

  public $ticketRestaurantMobileKey;
  public $ticketRestaurantMobileAntiPhishingKey;
  public $ticketRestaurantMobileOrderStatusPending;
  public $ticketRestaurantMobileOrderStatusConfirmed;

  private $_html = '';
  private $_postErrors = array();
  
  private function ticketrestaurantmobile_url_api() {
      return Configuration::get('TICKETRESTAURANTMOBILE_SANDBOX') == true 
          ? 'https://tr05sbx.paycritical.com/prestashop'
          : 'https://tr05.paycritical.com/prestashop';
  }

  public function __construct()
  {
    $this->name = 'ticketrestaurantmobile';
    $this->tab = 'payments_gateways';
    $this->version = '1.0.0';
    $this->author = 'Paycritical';
    $this->controllers = array('payment', 'validation');

    $this->currencies = true;
    $this->currencies_mode = 'checkbox';
		$this->is_eu_compatible = 1;
    $this->ps_versions_compliancy = array('min' => '1.6', 'max' => '1.7');
    $this->bootstrap = true;
    parent::__construct();
    $this->displayName = $this->l('Ticket Restaurant Mobile');
    $this->description = $this->l('This module allows payments via My Ticket App.');
    $this->confirmUninstall = $this->l('Are you sure you want to delete these details?');

    $config = Configuration::getMultiple(array('TICKETRESTAURANTMOBILE_KEY', 'TICKETRESTAURANTMOBILE_ANTI_PHISHING_KEY'));
    if (isset($config['TICKETRESTAURANTMOBILE_KEY'])) {
      Configuration::updateValue(self::FLAG_DISPLAY_PAYMENT_INVITE, true);
      $this->ticketRestaurantMobileKey = $config['TICKETRESTAURANTMOBILE_KEY'];
    }
    if (isset($config['TICKETRESTAURANTMOBILE_ANTI_PHISHING_KEY'])) {
      $this->ticketRestaurantMobileAntiPhishingKey = $config['TICKETRESTAURANTMOBILE_ANTI_PHISHING_KEY'];
    }
    if (isset($config['TICKETRESTAURANTMOBILE_ORDER_STATUS_PENDING'])) {
      $this->ticketRestaurantMobileOrderStatusPending = $config['TICKETRESTAURANTMOBILE_ORDER_STATUS_PENDING'];
    }

		if (isset($config['TICKETRESTAURANTMOBILE_ORDER_STATUS_CONFIRMED'])) {
      $this->ticketRestaurantMobileOrderStatusConfirmed = $config['TICKETRESTAURANTMOBILE_ORDER_STATUS_CONFIRMED'];
    }
			
    if (!count(Currency::checkPaymentCurrencies($this->id))) {
      $this->warning = $this->l('No currency has been set for this module.');
    }

    if (!isset($this->ticketRestaurantMobileKey)) {
      $this->warning = $this->l('You should configure the API Key first in order to be able to use') . ' ' . $this->displayName;
    }

    if (extension_loaded('curl') == false)
    {
      $this->warning =  $this->l('You have to enable the cURL extension on your server to use this module');
    }
			
  }

  private function smartCopy($source, $dest, $options=array('folderPermission'=>0755,'filePermission'=>0755))
	{
      $result=false;

      if (is_file($source)) {
        if ($dest[strlen($dest)-1]=='/') {
          if (!file_exists($dest)) {
            cmfcDirectory::makeAll($dest,$options['folderPermission'],true);
          }
          $__dest=$dest."/".basename($source);
        } else {
          $__dest=$dest;
        }
        $result=copy($source, $__dest);
        chmod($__dest,$options['filePermission']);

      } elseif(is_dir($source)) {
        if ($dest[strlen($dest)-1]=='/') {
          if ($source[strlen($source)-1]=='/') {
            //Copy only contents
          } else {
            //Change parent itself and its contents
            $dest=$dest.basename($source);
            @mkdir($dest);
            chmod($dest,$options['filePermission']);
          }
        } else {
          if ($source[strlen($source)-1]=='/') {
            //Copy parent directory with new name and all its content
            @mkdir($dest,$options['folderPermission']);
            chmod($dest,$options['filePermission']);
          } else {
            //Copy parent directory with new name and all its content
            @mkdir($dest,$options['folderPermission']);
            chmod($dest,$options['filePermission']);
          }
        }

        $dirHandle=opendir($source);
        while($file=readdir($dirHandle))
        {
          if($file!="." && $file!="..")
          {
            if(!is_dir($source."/".$file)) {
              $__dest=$dest."/".$file;
            } else {
              $__dest=$dest."/".$file;
            }
            $result=smartCopy($source."/".$file, $__dest, $options);
          }
        }
        closedir($dirHandle);
      } else {
        $result=false;
      }
      return $result;
    }

  private function create_states($configuration, $message, $color, $send_email = false, $template = '')
  {
    if (!Configuration::get($configuration)) {
      $order_state = new OrderState();
      $order_state->name = array();

      $stateTranslastions = array(
        "pending" => array(
                            "pt" => "Pagamento Ticket Restaurant Mobile pendente",
                            "en" => "Awaiting Ticket Restaurant Mobile payment"
                            ),
        "completed" => array(
                            "pt" => "Pagamento Ticket Restaurant Mobile confirmado",
                            "en" => "Ticket Restaurant Mobile payment confirmed"
                            )
       );

      foreach (Language::getLanguages() as $language) {
        $order_state->name[$language['id_lang']] = $this->l($message);
        if (strtolower($language['iso_code']) == 'pt')
		$order_state->name[$language['id_lang']] = $stateTranslastions[$message]['pt'];
		else
		$order_state->name[$language['id_lang']] =  $stateTranslastions[$message]['en'];
      }

      $order_state->module_name = $this->name;
      $order_state->send_email = $send_email;
      $order_state->template = $template;
      $order_state->color = '#' . $color;
      $order_state->hidden = false;
      $order_state->delivery = false;
      $order_state->logable = false;
      $order_state->invoice = false;
      $order_state->unremovable = true;

      if ($order_state->add()) {
        $source = dirname(__FILE__).'/views/img/status.gif';
        $destination = dirname(__FILE__).'/../../img/os/'.(int) $order_state->id.'.gif';
        copy($source, $destination);
      }
  
      Configuration::updateValue($configuration, (int) $order_state->id);
    }
  }

  public function install()
  {
    if (extension_loaded('curl') == false)
    {
        $this->_errors[] = $this->l('You have to enable the cURL extension on your server to use this module');
        return false;
    }

    Configuration::updateValue(self::FLAG_DISPLAY_PAYMENT_INVITE, true);

    $this->create_states('TICKETRESTAURANTMOBILE_ORDER_STATUS_PENDING', 'pending', '4169E1');
    $this->create_states('TICKETRESTAURANTMOBILE_ORDER_STATUS_CONFIRMED', 'completed', '32CD32', true, 'payment');
    
    if(Configuration::get('TICKETRESTAURANTMOBILE_ANTI_PHISHING_KEY') == "") {
        Configuration::updateValue('TICKETRESTAURANTMOBILE_ANTI_PHISHING_KEY', md5(time()));
    }

    if (version_compare(_PS_VERSION_, '1.7', '>=')) {
      if (
        !parent::install() ||
        !$this->registerHook('paymentOptions') ||
        !$this->registerHook('paymentReturn') ||
        !$this->registerHook('header')
      ) {
          return false;
      }
    } else {
      if (
        !parent::install() ||
        !$this->registerHook('payment') ||
        !$this->registerHook('displayPaymentEU') ||
        !$this->registerHook('header') ||
        !$this->registerHook('paymentReturn')
      ) {
          return false;
      }
    }
    return true;
  }

  public function uninstall() {
    Configuration::updateValue('TICKETRESTAURANTMOBILE_ANTI_PHISHING_KEY', "");
    Configuration::updateValue('TICKETRESTAURANTMOBILE_KEY', "");
    Configuration::deleteByName(self::FLAG_DISPLAY_PAYMENT_INVITE);
    return parent::uninstall();
  }

  private function _infoTable()
  {
    $this->_html .= '<div style="background: white;">
		<table style="margin-bottom: 20px;">
			<tr>
                <td>
                    <img style="padding: 20px;" src="../modules/' . $this->name . '/logo.png" />
                </td>
				<td>
					<b>'.$this->l('This method allow payments via My Ticket app.').'</b>
					<br />
					<b>'.$this->l('Access the').' <u><a href="http://aderentes.ticket.pt/" target="_blank">'.$this->l('Portal').'</a></u> '.$this->l('to generate a new API key').'.</b>
				</td>
			</tr>
    </table></div>';
  }

	private function _displayForm()
	{
        $sandboxMode = Configuration::get('TICKETRESTAURANTMOBILE_SANDBOX')==true 
        ? '<tr><td>Sandbox Mode</td><td>Active</td></tr>'
        : '';

		$this->_html .=
		'<div style="background: white;"><form action="'.Tools::htmlentitiesUTF8($_SERVER['REQUEST_URI']).'" method="post">
			<fieldset>
			<legend>'.$this->l('Payment method configuration').'</legend>
				<table border="0" width="100%" cellpadding="0" cellspacing="0" id="form">
                    '.$sandboxMode.'
                    <tr><td>'.$this->l('PrestaShop Site').':</td><td>'.$this->context->shop->getBaseURL(true).'</td></tr>
                    <tr><td>'.$this->l('PrestaShop Key').':</td><td>'.Configuration::get('TICKETRESTAURANTMOBILE_ANTI_PHISHING_KEY').'</td></tr>
					<tr><td width="130" style="height: 35px;">'.$this->l('Ticket Restaurant Mobile API Key').':</td><td><input type="text" name="ticketrestaurantmobile_key" placeholder="Basic xxxxxxxxxxxxxxxxxx" value="'.htmlentities(Tools::getValue('ticketrestaurantmobile_key', $this->ticketRestaurantMobileKey), ENT_COMPAT, 'UTF-8').'" style="width: 100%;" /></td></tr>
					<tr><td colspan="2" style="padding-top: 20px; padding-bottom: 20px;" align="center"><input class="button" name="btnSubmit" value="'.$this->l('Save').'" type="submit" /></td></tr>
				</table>
			</fieldset>
		</form></div>';
	}

	private function _postProcess()
	{
		if (Tools::isSubmit('btnSubmit'))
		{
            Configuration::updateValue('TICKETRESTAURANTMOBILE_SANDBOX', Tools::getValue('s') == '1');
            Configuration::updateValue('TICKETRESTAURANTMOBILE_KEY', Tools::getValue('ticketrestaurantmobile_key'));
		}
		$this->_html .= '<div class="conf confirm">'.$this->l('Updated successfully').'</div>';
	}

	private function _postValidation()
	{
        $erro = "";
        if (Tools::isSubmit('btnSubmit'))
		{
		    if (!Tools::getValue('ticketrestaurantmobile_key'))
            $erro = $this->l('Please set Ticket Restaurant Mobile API Key');
		}
        else {
            if(!Configuration::get('TICKETRESTAURANTMOBILE_KEY')) 
            $erro = $this->l('Please set Ticket Restaurant Mobile API Key');
        }

		if($erro!="")
		$this->_postErrors[] = $erro . '.';
	}

  public function getContent()
	{
			$this->_postValidation();
			if (!count($this->_postErrors))
				$this->_postProcess();
			else
				foreach ($this->_postErrors as $err)
					$this->_html .= '<div class="alert error" style="color: red;">'.$err.'</div>';

    $this->_infoTable();
    $this->_displayForm();

    return $this->_html;
  }

  public function checkCurrency($cart)
	{
		$currency_order = new Currency($cart->id_currency);
		$currencies_module = $this->getCurrency($cart->id_currency);

        if($currency_order->iso_code != 'EUR'){
            return false;
        }

		if (is_array($currencies_module))
			foreach ($currencies_module as $currency_module)
				if ($currency_order->id == $currency_module['id_currency'])
					return true;
		return false;
  }
  
  protected function generateForm($version = '')
  {
    $this->context->smarty->assign([
        'action' => $this->context->link->getModuleLink($this->name, 'validation', array(), true),
    ]);
    return $this->display(__FILE__, 'mobilephone' . ($version !== '' ? '_' . $version : '') . '.tpl');
  }

  public function hookPaymentOptions($params)
  {
    if (!$this->active) {
			return;
		}

		if (!$this->checkCurrency($params['cart'])) {
			return;
    }        

    $paymentOption = new PrestaShop\PrestaShop\Core\Payment\PaymentOption();
    $paymentOption->setModuleName($this->name)
            ->setCallToActionText($this->l('Ticket Restaurant Mobile Payment'))
            ->setForm($this->generateForm());

    $payment_options = [
      $paymentOption,
    ];

    return $payment_options;
  }

  public function hookPayment($params)
	{
		if (!$this->active)
			return;

		if (!$this->checkCurrency($params['cart']))
			return;

        if(!Configuration::get('TICKETRESTAURANTMOBILE_KEY')) 
        return;

		$this->smarty->assign(array(
      'module_name' => $this->name,
			'this_path' => $this->_path,
			'this_path_bw' => $this->_path,
			'this_path_ssl' => Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/'.$this->name.'/'
		));
		return $this->display(__FILE__, 'payment.tpl');
	}

	public function hookDisplayPaymentEU($params)
	{
		if (!$this->active)
			return;

		if (!$this->checkCurrency($params['cart']))
			return;

        if(!Configuration::get('TICKETRESTAURANTMOBILE_KEY')) 
        return;

		$payment_options = array(
			'cta_text' => $this->l('Ticket Restaurant Mobile Payment'),
			'logo' => Media::getMediaPath(_PS_MODULE_DIR_.$this->name.'/logo.png'),
			'action' => $this->context->link->getModuleLink($this->name, 'validation', array(), true)
		);

		return $payment_options;
	}

  public function hookHeader()
  {
    if (version_compare(_PS_VERSION_, '1.7', '>=')) {
      $this->context->controller->registerJavascript('modules-ticketrestaurantmobile', 'modules/'.$this->name.'/views/js/ticketrestaurantmobile.js', ['position' => 'bottom', 'priority' => 150]); 
    } else {
      $this->context->controller->addJS($this->_path . '/views/js/ticketrestaurantmobile.js');
    }
  }

  private function callTicketRestaurantMobileAPI($reference, $orderId, $name, $phoneNumber, $amount) 
  {

    // Get cURL resource
    $curl = curl_init();

    // Set some options - we are passing in a useragent too here
    curl_setopt_array($curl, array(
      CURLOPT_RETURNTRANSFER => 1,
      CURLOPT_URL => $this->ticketrestaurantmobile_url_api() . '?apiKey=' . urlencode(Configuration::get('TICKETRESTAURANTMOBILE_KEY')) . '&orderId=' . $orderId . '&amount=' . $amount . '&phoneNumber=' . $phoneNumber . '&reference=' . $reference . '&description=' . urlencode ('Enc.: #' . $orderId . ' (' . $reference . ') ' . $name),
      CURLOPT_USERAGENT => 'Ticket Restaurant Mobile Prestashop Client'
    ));

    // Send the request & save response to $resp
    $resp = curl_exec($curl);
    // Close request to clear up some resources
    curl_close($curl);

    return json_decode($resp);
  }

  public function ptPrice($price)
  {
    return number_format($price, 2, ',', '');
  }

  public function hookPaymentReturn($params)
  {
    if (!$this->active) {
        return;
    }

    $order = (version_compare(_PS_VERSION_, '1.7', '>=')) ? $params['order'] : $params['objOrder'];

    $phoneNumber = Configuration::get('TICKETRESTAURANTMOBILE_CART_' . $order->id_cart);
    
    $isPending = ((int)$order->current_state === ((int)Configuration::get('TICKETRESTAURANTMOBILE_ORDER_STATUS_PENDING')));

    if ($isPending) 
    {
      $totalPaid = $this->ptPrice($order->total_paid);
      $shopName = Configuration::get('PS_SHOP_NAME');
      $result = $this->callTicketRestaurantMobileAPI($order->reference, $order->id, $shopName, $phoneNumber, $totalPaid);

      if (Configuration::get('TICKETRESTAURANTMOBILE_CALLBACK_' . $order->id) === false) 
      {
          Configuration::updateValue('TICKETRESTAURANTMOBILE_REFERENCE' . $order->id, $order->reference);
          if($result->Status !== 'OK') 
          {
            $history = new OrderHistory();
            $history->id_order = (int)$order->id;
            $history->changeIdOrderState((int)Configuration::get('PS_OS_ERROR'), (int)($order->id));
          }
      }
    }   

    $this->context->smarty->assign(array(
			'this_path' 	=> $this->_path,
            'phoneNumber'   => $phoneNumber,
            'status'        => $result->Status
		));
    
    return $this->display(__FILE__, 'payment_return.tpl');
  }

  public function processCallback($key, $orderId, $status)
  {
    global $link;
	$context = Context::getContext();
    $context->link = new Link();
    
    $config_key = Configuration::get('TICKETRESTAURANTMOBILE_ANTI_PHISHING_KEY');
    
    $order = new Order((int)$orderId);

    if (!Validate::isLoadedObject($order))
        return 'NotFound';

    $isPending = ((int)$order->current_state === ((int)Configuration::get('TICKETRESTAURANTMOBILE_ORDER_STATUS_PENDING')));

    if ( $isPending && $config_key === $key)
    {
      if ($status === 'Paid')
      {
        $new_history = new OrderHistory();
        $new_history->id_order = (int)$orderId;
        $new_history->changeIdOrderState((int)Configuration::get('TICKETRESTAURANTMOBILE_ORDER_STATUS_CONFIRMED'), (int)$orderId);
        $new_history->addWithemail(true, null, $context);

        return "OK";
      } else {
        $history = new OrderHistory();
        $history->id_order = (int)$orderId;
        $history->changeIdOrderState((int)Configuration::get('PS_OS_ERROR'), (int)$orderId);

        return "Failed";
      }
    } else {
      return "NotFound";
    }
  }
}
