<?php

class TicketRestaurantMobileCallbackModuleFrontController extends ModuleFrontController
{
	public $ssl = true;

	/**
	 * @see FrontController::initContent()
	 */
	public function initContent()
	{
    parent::initContent();

		$key = '';
		$orderId = '';
		$status = '';

		if (isset($_GET['key'])) $key = $_GET['key'];
		if (isset($_GET['orderId'])) $orderId = $_GET['orderId'];
		if (isset($_GET['status'])) $status = $_GET['status'];

		die($this->module->processCallback($key, $orderId, $status));
  }
}
